package com.jeapie;

/**
 * Created by user on 13.03.14.
 */
public class FakeInformationProvider implements InformationProvider {

    private final String manufacturer;
    private final String model;
    private final String androidVersion;
    private final int displayWidth;
    private final int displayHeight;
    private final String uuid;

    FakeInformationProvider(String manufacturer, String model, String androidVersion, int displayWidth, int displayHeight, String uuid) {
        this.manufacturer = manufacturer;
        this.model = model;
        this.androidVersion = androidVersion;
        this.displayWidth = displayWidth;
        this.displayHeight = displayHeight;
        this.uuid = uuid;
    }

    @Override
    public String getManufacturer() {
        return manufacturer;
    }

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public String getAndroidVersion() {
        return androidVersion;
    }

    @Override
    public int getDisplayWidth() {
        return displayWidth;
    }

    @Override
    public int getDisplayHeight() {
        return displayHeight;
    }

    @Override
    public String getUuid() {
        return uuid;
    }
}
