//package com.jeapie;
//
//import com.jeapie.util.JSONArrayFile;
//import com.jeapie.util.json.JSONArray;
//import com.jeapie.util.json.JSONObject;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.junit.runners.JUnit4;
//
//import java.io.File;
//import java.io.IOException;
//
//import static org.junit.Assert.*;
//
//@RunWith(JUnit4.class)
//public class JSONSaverTest {
//
//    private JSONArrayFile saver;
//    private File file = new File("json-test.json");
//
//    @Before
//    public void before(){
//        saver = new JSONArrayFile(file);
//    }
//
//    @Test
//    public void writeJSONArrayTest() throws IOException {
//        JSONArray array = new JSONArray();
//        array.put(1.);
//        array.put("Ololo");
//        array.put(new JSONObject());
//
//        saver.write(array);
//
//        JSONArray readedArray  = saver.read();
//
//        assertTrue(array.length() == readedArray.length());
//    }
//}
