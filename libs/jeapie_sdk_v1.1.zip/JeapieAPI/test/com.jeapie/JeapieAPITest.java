//package com.jeapie;
//
//import com.jeapie.util.json.JSONArray;
//import com.jeapie.util.json.JSONObject;
//import org.junit.BeforeClass;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.junit.runners.JUnit4;
//
//import java.util.Date;
//import java.util.Map;
//import java.util.UUID;
//
//import static org.junit.Assert.*;
//
//@RunWith(JUnit4.class)
//public class JeapieAPITest {
//
//    private static Map<String, Object> openEvent;
//    private static Map<String, Object> tokenEvent;
//
//    private static InformationProvider fake;
//
//    @BeforeClass
//    public static void before() {
//        fake = new FakeInformationProvider("Meizu", "MX2", "4.1", 1024, 768, UUID.randomUUID().toString());
//
//        openEvent = EventBuilder.buildOpenEvent(new Date());
//        tokenEvent = EventBuilder.buildTokenEvent("OloloTrololo");
//    }
//
//    @Test
//    public void testEventsToSendInsertGeneralInfoFirstTest() {
//        JeapieAPI api = new JeapieAPI(null, null, fake, null);
//
//        assertTrue(api.eventsToSend().length() == 0);
//
//        api.addEvent(openEvent);
//
//        assertTrue(api.eventsToSend().length() == 2);
//    }
//
//
//    @Test
//    public void testEventsToSendAfterFirst() {
//        JeapieAPI api = new JeapieAPI(null, null, fake, null);
//
//        api.addEvent(openEvent);
//        api.addEvent(tokenEvent);
//
//        assertTrue(api.eventsToSend().length() == 3);
//    }
//
//    @Test
//    public void testEventsToSendEachHaveUuid() {
//        JeapieAPI api = new JeapieAPI(null, null, fake, null);
//
//        api.addEvent(openEvent);
//        api.addEvent(tokenEvent);
//
//        JSONArray eventsArray = api.eventsToSend();
//        for (int i = 0; i < eventsArray.length(); i++) {
//            JSONObject eventObject = (JSONObject) eventsArray.get(i);
//            assertNotNull(eventObject.get("uuid"));
//        }
//    }
//}
