package com.jeapie;

import com.jeapie.util.json.JSONArray;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Utility class, builds Jeapie API events
 */
class EventBuilder {
    /**
     * Server date format
     */
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");

    private EventBuilder() {
    }

    /**
     * Builds open api event
     *
     * @param date open date
     */
    public static Map<String, Object> buildOpenEvent(Date date) {
        Map<String, Object> res = new HashMap<String, Object>();

        res.put("type", "open");
        res.put("time", dateFormat.format(date));

        return res;
    }

    /**
     * Builds register GCM tokin api event
     *
     * @param token GCM token
     */
    public static Map<String, Object> buildTokenEvent(String token) {
        Map<String, Object> res = new HashMap<String, Object>();

        res.put("token", token);

        return res;
    }

    /**
     * Builds push api event
     *
     * @param mId  m_id field from push message
     * @param date push date
     */
    public static Map<String, Object> buildPushEvent(String mId, Date date) {
        Map<String, Object> res = new HashMap<String, Object>();

        res.put("type", "push");
        res.put("m_id", mId);
        res.put("time", dateFormat.format(date));

        return res;
    }

    /**
     * Builds close session api event
     *
     * @param duration session duration in seconds
     */
    public static Map<String, Object> buildSessionEvent(long duration) {
        Map<String, Object> res = new HashMap<String, Object>();

        res.put("session", String.valueOf(duration));

        return res;
    }

    /**
     * Builds tags added api event
     *
     * @param tags list of tags
     */
    public static Map<String, Object> buildTagsEvent(List<String> tags) {
        Map<String, Object> res = new HashMap<String, Object>();

        res.put("tags", new JSONArray(tags));

        return res;
    }
}
