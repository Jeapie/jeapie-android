package com.jeapie;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.google.android.gms.gcm.GoogleCloudMessaging;

import java.util.Date;

/**
 * GCMReceiver for handling Google Cloud Messaging intents.
 * <p/>
 * <p>You can use GCMReceiver to report Google Cloud Messaging registration identifiers
 * to app associated with Jeapie.
 * <p/>
 * <p>To enable GCMReceiver in your application, add a clause like the following
 * to the &lt;application&gt; tag of your AndroidManifest.xml. (Be sure to replace "YOUR APPLICATION PACKAGE NAME"
 * in the snippet with the actual package name of your app.)
 * <p/>
 * <pre>
 * {@code
 *
 * <receiver android:name="com.jeapie.GCMReceiver" >
 *  <intent-filter>
 *      <action android:name="com.google.android.c2dm.intent.RECEIVE" />
 *      <action android:name="com.google.android.c2dm.intent.REGISTRATION" />
 *      <category android:name="YOUR APPLICATION PACKAGE NAME" />
 *  </intent-filter>
 * </receiver>
 *
 * }
 * </pre>
 * <p/>
 * <p>In addition, GCMReceiver will also need the following permissions configured
 * in your AndroidManifest.xml file:
 * <p/>
 * <pre>
 * {@code
 *
 * <!-- Be sure to change YOUR_PACKAGE_NAME to the real name of your application package -->
 * <permission android:name="YOUR_PACKAGE_NAME.permission.C2D_MESSAGE" android:protectionLevel="signature" />
 * <uses-permission android:name="YOUR_PACKAGE_NAME.permission.C2D_MESSAGE" />
 *
 * <uses-permission android:name="android.permission.INTERNET" />
 * <uses-permission android:name="android.permission.GET_ACCOUNTS" />
 * <uses-permission android:name="com.google.android.c2dm.permission.RECEIVE" />
 * <uses-permission android:name="android.permission.WAKE_LOCK" />
 *
 * }
 * </pre>
 */
public class GCMReceiver extends BroadcastReceiver {
    public static final String M_ID_EXTRA_FIELD = "m_id";
    public static final String REGISTRATION_ID_EXTRA_FIELD = "registration_id";

    @Override
    public void onReceive(Context context, Intent intent) {
        final String action = intent.getAction();
        if ("com.google.android.c2dm.intent.REGISTRATION".equals(action)) {
            handleRegistrationIntent(intent);
        } else if ("com.google.android.c2dm.intent.RECEIVE".equals(action)) {
            handleNotificationIntent(context, intent);
        }
    }

    private void handleRegistrationIntent(Intent intent) {
        final String registration = intent.getStringExtra(REGISTRATION_ID_EXTRA_FIELD);

        if (registration != null) {
            try {
                JeapieAPI.getInstance().addEvent(EventBuilder.buildTokenEvent(registration));
            } catch (Error e) {
                Log.e(JeapieAPI.LOGTAG, "JeapieAPI isn't initialisated!", e);
            }
        }
    }

    private void handleNotificationIntent(Context context, Intent intent) {
        GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(context);
        String messageType = gcm.getMessageType(intent);

        if (GoogleCloudMessaging.MESSAGE_TYPE_MESSAGE.equals(messageType)) {
            final String mId = intent.getStringExtra(M_ID_EXTRA_FIELD);
            if (mId != null) {
                JeapieAPI.getInstance().addEvent(EventBuilder.buildPushEvent(mId, new Date()));
            }
            Intent notifyIntent = (Intent) intent.clone();
            notifyIntent.removeExtra(M_ID_EXTRA_FIELD);
            JeapieAPI.getInstance().notifyPushListener(notifyIntent);
        }
    }
}